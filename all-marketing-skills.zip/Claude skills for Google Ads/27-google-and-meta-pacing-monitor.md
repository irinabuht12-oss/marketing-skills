---
name: pacing-monitor
description: Tracks daily spend against monthly budget targets across all campaigns and accounts. Tells you exactly where you'll land at current pace, flags campaigns that are over or underspending, and calculates the daily budget adjustments needed to hit your target by month end.
metadata:
  platform: Google and Meta
---

# 27/ Pacing Monitor — Google + Meta

## What it does
Tracks daily spend against monthly budget targets across all campaigns and accounts. Tells you exactly where you'll land at current pace, flags campaigns that are over or underspending, and calculates the daily budget adjustments needed to hit your target by month end.

## How it works
Claude takes your current month-to-date spend, remaining days in the month, and monthly budget targets, then projects end-of-month spend at the current run rate. It accounts for weekday vs weekend spend patterns and flags any campaigns that need immediate budget adjustments to stay on track.

## Practical example
It's the 14th of the month. Your total monthly target is $120K across 6 campaigns. Current MTD spend is $52K. At the current daily rate, you'll end at $111K — $9K under target. But the underspend isn't evenly distributed: Campaign A is pacing 15% over target and will overshoot by $3,200, while Campaign D is pacing 40% under because it's limited by bid caps. Claude calculates that Campaign D needs its daily budget increased from $800 to $1,350 and bid caps loosened by 20% to catch up, while Campaign A should be pulled back from $2,100/day to $1,800/day.

## What you get back
- Overall account pacing vs target with projected end-of-month spend
- Campaign-by-campaign pacing status (on track, overspending, underspending)
- Exact daily budget needed for each campaign to hit monthly target
- Flags for campaigns limited by budgets, bids, or audience size that can't scale to meet target
- Historical pacing patterns showing if your account typically front-loads or back-loads spend in a month

## When to use it
- Weekly pacing checks, ideally every Monday and mid-week
- When clients have strict monthly budgets that can't be exceeded
- During heavy spend periods (holiday, promotions) where daily oversight matters more
- End of month when you need to throttle or accelerate to land on target

## Data access (Ryze MCP)

This skill works best with live account data. Connect the free Ryze MCP once and Claude reads your Google Ads, Meta Ads, GA4 and Search Console directly:

- claude.ai / Claude Desktop: Settings → Connectors → Add custom connector → `https://connector.get-ryze.ai/mcp`
- Claude Code: `claude mcp add ryze --transport http https://connector.get-ryze.ai/mcp`
- Cursor: Settings → MCP → add the same URL

Setup guide: https://www.get-ryze.ai/how-to-connect-claude-to-google-meta-ads-mcp
